plugins {
	base
	id("moulconfig.base")
	alias(libs.plugins.mkdocs)
	id("moulconfig.dokka.base")
}

mkdocs {
	python {
		pip("mkdocs-zettelkasten:0.1.9")
	}
	publish {
		docPath = ""
	}
	strict = false
}

val compileAllDocs = tasks.register("compileAllDocs", Copy::class) {
    dependsOn(tasks.mkdocsBuild)
    destinationDir = layout.buildDirectory.dir("allDocs").get().asFile
    from(tasks.mkdocsBuild)
    from(tasks.dokkaGeneratePublicationHtml.flatMap { it.outputDirectory }) {
        into("javadocs")
    }
}
val docJar = tasks.register("docJar", Zip::class) {
    from(compileAllDocs)
    archiveClassifier.set("docs")
}
val docConfig = configurations.create("documentation")
artifacts.add(docConfig.name, docJar)
tasks.assemble { dependsOn(docJar) }

dependencies {
    dokka(project(":common"))
//    dokka(project(":legacy"))
//    dokka(project(":modern"))
}
