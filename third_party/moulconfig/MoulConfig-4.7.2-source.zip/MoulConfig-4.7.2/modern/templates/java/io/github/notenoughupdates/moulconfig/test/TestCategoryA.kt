package io.github.notenoughupdates.moulconfig.test

import com.google.gson.annotations.Expose
import io.github.notenoughupdates.moulconfig.ChromaColour
import io.github.notenoughupdates.moulconfig.annotations.*
import io.github.notenoughupdates.moulconfig.observer.Property
import org.lwjgl.glfw.GLFW
import java.util.*

class TestCategoryA {

    @Expose
    @ConfigOrder(Integer.MAX_VALUE)
    @ConfigOption(name = "Bottom option!", desc = "Declared at top, but should appear at the bottom by Order annotation.")
    @ConfigEditorInfoText(infoTitle = "Bottom option")
    var bottomOption: Boolean = false

    @ConfigOption(name = "Open Wide", desc = "Use a wider config menu")
    @ConfigEditorBoolean
    var isWide: Boolean = false

    @ConfigOption(name = "Test Option", desc = "Test toggle")
    @ConfigEditorBoolean
    var shouldTestToggle: Boolean = false

    @ConfigOption(name = "Pronouns in MoulConfig", desc = "Fuck It")
    @ConfigEditorDropdown
    var dropdownTest: Pronouns = Pronouns.ITITS

    enum class Pronouns(val label: String) {
        HEHIM("He/Him"),
        SHEHER("She/Her"),
        ITITS("It/Its"),
        THEYTHEM("They/Them"),
        USE_NAME("Use Name"),
        ;

        override fun toString(): String {
            return label
        }
    }


    @Accordion
    @ConfigOption(name = "Accordion", desc = "")
    var accordion = AccordionClass()

    class AccordionClass() {

        @ConfigOption(name = "Number Dropdown", desc = "0, 1, 2, 3")
        @ConfigEditorDropdown(values = ["0", "1", "2", "3"])
        var numberDropdown: Int = 0

        @Expose
        @ConfigOption(name = "Drop Down", desc = "Using strings")
        @ConfigEditorDropdown(values = ["A", "B", "C"])
        var dropDownUisngStrings: String = "A"


        @ConfigOption(name = "Enum Dropdown", desc = "1, 2, 3, 4")
        @ConfigEditorDropdown
        var enumDropdown: Property<DropdownEnum> = Property.of(DropdownEnum.FOUR)
    }

    enum class DropdownEnum(private val label: String) {
        ONE("1"),
        TWO("2"),
        THREE("3"),
        FOUR("4"),
        ;

        override fun toString(): String {
            return label
        }
    }

    @ConfigOption(name = "Slider", desc = "Between 1 and 5")
    @ConfigEditorSlider(minValue = 1F, maxValue = 5f, minStep = 1F)
    var minimumTitle: Int = 1

    @ConfigOption(name = "Info Box", desc = "Shows important info to the user")
    @ConfigEditorInfoText(
        infoTitle = "§cAlert",
    )
    var notice: String = ""

    @ConfigOption(name = "Text Box", desc = "Lets you put strings.")
    @ConfigEditorText(forbidden = "§z")
    var customText: Property<String> = Property.of("abc")

    @ConfigOption(name = "Draggable List", desc = "§eDrag text to change the order of the list.")
    @ConfigEditorDraggableList(
        exampleText = [
            "abc", "dec", "blah", "surel it works really cool and great :))",
            "Lorem ipsum semper",
            "auctor neque vitae",
            "tempus quam pellentesque",
            "Turpis egestas maecenas",
            "pharetra convallis posuere",
            "Malesuada fames ac",
            "turpis egestas maecenas",
            "In cursus turpis",
            "Gravida neque convallis",
            "a cras semper",
            "auctor neque vitae",
            "Dui faucibus in",
            "Consequat nisl vel",
            "pretium lectus quam",
            "id leo in",
            "Eget est lorem",
            "ipsum dolor sit",
            "Enim facilisis gravida",
            "neque convallis a",
            "Non arcu risus",
            "quis varius quam",
            "Enim praesent elementum",
            "facilisis leo vel",
            "Elementum sagittis vitae",
            "et leo duis",
            "Nisi lacus sed",
            "Id aliquet lectus",
            "proin nibh nisl",
            "Egestas sed sed",
            "risus pretium quam",
            "A iaculis at",
            "erat pellentesque adipiscing",
            "Etiam dignissim diam",
            "quis enim lobortis",
            "Lacus suspendisse faucibus",
            "interdum posuere lorem",
            "ipsum dolor sit",
            "Mattis nunc sed",
            "Eu lobortis elementum",
            "nibh tellus molestie",
            "Eget duis at",
            "tellus at urna",
            "Sagittis aliquam malesuada",
            "bibendum arcu vitae",
            "Felis imperdiet proin",
            "fermentum leo vel",
            "Sed sed risus",
            "Sed risus pretium",
            "quam vulputate dignissim",
            "Fames ac turpis",
            "egestas maecenas pharetra",
            "Lobortis scelerisque fermentum",
            "dui faucibus in",
            "Aenean pharetra magna",
            "ac placerat vestibulum",
            "Aliquet sagittis id",
            "Netus et malesuada",
            "Habitant morbi tristique",
            "Habitasse platea dictumst",
            "Egestas sed sed",
            "risus pretium quam",
            "Amet consectetur adipiscing",
            "elit ut aliquam",
            "purus sit amet",
            "Mauris commodo quis",
            "imperdiet massa tincidunt",
            "Arcu felis bibendum",
            "ut tristique et",
            "Blandit volutpat maecenas",
            "volutpat blandit aliquam",
            "Quisque sagittis purus",
            "sit amet volutpat",
            "Mattis vulputate enim",
            "Sit amet facilisis",
            "magna etiam tempor",
            "Erat nam at",
            "lectus urna duis",
            "Sit amet est",
            "Nunc pulvinar sapien",
            "et ligula ullamcorper",
            "malesuada proin libero",
            "Amet justo donec",
            "enim diam vulputate",
            "Adipiscing vitae proin",
            "sagittis nisl rhoncus",
            "At ultrices mi",
            "tempus imperdiet nulla",
            "Fermentum odio eu",
            "feugiat pretium nibh",
            "Felis imperdiet proin",
            "fermentum leo vel",
            "Consequat ac felis",
            "donec et odio",
        ]
    )
    var draggableList: List<Int> = ArrayList(mutableListOf(0, 1, 2, 3))

    @Expose
    @ConfigOption(name = "Enum Draggable List", desc = "Draggable list but doesnt work properly.")
    @ConfigEditorDraggableList
    var enumDraggableList: List<EnumDraggableList> = ArrayList(
        Arrays.asList(
            EnumDraggableList.ONE,
            EnumDraggableList.THREE,
            EnumDraggableList.TWO,
        )
    )

    enum class EnumDraggableList(private val str: String) {
        ONE("1"),
        TWO("too"),
        THREE("three"),
        ;

        override fun toString(): String {
            return str
        }
    }

    @ConfigOption(name = "Colour Test", desc = "Test a colour editor")
    @ConfigEditorColour
    var colour = ChromaColour(0F, 1f, 1f, 0, 0xFF)

    @Expose
    @ConfigOption(name = "Keybind", desc = "The Number One")
    @ConfigEditorKeybind(defaultKey = GLFW.GLFW_KEY_1)
    var slot1: Int = GLFW.GLFW_KEY_1


    @Expose
    @ConfigOption(name = "Test Runnable", desc = "Test a java.lang.Runnable")
    @ConfigEditorButton(buttonText = "Click me")
    val runnable = Runnable {
        println("JRunnable working")
    }

    @Expose
    @ConfigOption(name = "Test Runnable", desc = "Test a kotlin.jvm.functions.Function0")
    @ConfigEditorButton(buttonText = "Click me")
    val kRunnable = {
        println("KFunction0 working")
    }

    @Expose
    @ConfigOption(name = "Test Runnable", desc = "Test a (ignored) runnable using runnableId to emit a test warning")
    @ConfigEditorButton(
        runnableId = 10,
        buttonText = "Click me"
    )
    val runnableId = Unit

    @Expose
    @ConfigOrder(-1)
    @ConfigOption(name = "Top option!", desc = "Declared at the bottom, floated to top by Order annotation.")
    @ConfigEditorInfoText(infoTitle = "Top option")
    var topOption: Boolean = false

}
